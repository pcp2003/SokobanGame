package interfaces;

// Interface Removable facilita a remocao e novos elementos que possam ser
// adicionados ao Game.
// ---- isRemovable() ----- indica se elemento e' removivel naquele momento
// ---- beRemovable() ----- torna o elemento removivel, caso alguma interacao
// indique para o fazer.
public interface Removable {
	
	public boolean isRemovable();
	
	public void beRemovable();

}
