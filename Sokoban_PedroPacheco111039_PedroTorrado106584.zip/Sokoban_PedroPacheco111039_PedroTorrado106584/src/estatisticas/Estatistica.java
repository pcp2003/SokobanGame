package estatisticas;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.HashMap;

// O formato para guardar as estatísticas num ficheiro .txt é (1:Miguel,55;Pedro,57;Pedro,57;)
// O primeiro INT (1) corresponde ao level.
// Miguel,55 corresponde ao nome associado por uma vírgula a pontuação
// O level está separado do resto da informação por ":"
// As direfentes pontuações (Nome + pontuação) estão separadas por ";".

public class Estatistica {
	
	// HashMap que recebe um level (Integer) como KEY e tem como VALUE uma lista de registros.
	private Map<Integer, List<Registro>> estatisticas;

	public Estatistica() {
		estatisticas = new HashMap<>();
	}
	
	// Carrega e processa a informação contida num ficheiro ".txt"
	public void carregarEstatisticasDoArquivo(String caminhoArquivo) {

		try {
			Scanner scanner = new Scanner(new File(caminhoArquivo));
			while (scanner.hasNextLine()) {

				String linha = scanner.nextLine();

				String[] registrosPorLevel = linha.split(":");

				// {level}{resto}

				int lvl = Integer.parseInt(registrosPorLevel[0]);

				String[] registroSemOrdem = registrosPorLevel[1].split(";");
				// {Pedro,10}{Caio,15}

				List<Registro> registros = new ArrayList<>();
				for (int i = 0; i != registroSemOrdem.length; i++) {
					String[] nomePontuacao = registroSemOrdem[i].split(",");
					registros.add(new Registro(nomePontuacao[0], Integer.parseInt(nomePontuacao[1])));

				}

				estatisticas.put(lvl, registros);

			}
		} catch (FileNotFoundException e) {
			System.err.println("Erro na abertura do ficheiro");
		}
	}
	
	// Adiciona a pontuação de um jogador associado ao seu Level ao HashMap da Estatistica
	public void adicionarPontuacao(Registro registro, int level) {

		List<Registro> registros;

		if (estatisticas.get(level) == null) {
			registros = new ArrayList<>();
			registros.add(registro);
		} else {
			registros = estatisticas.get(level);
			registros.add(registro);
			registros.sort((o1, o2) -> o1.getPontuacao() - o2.getPontuacao());
			registros = registros.subList(0, Math.min(registros.size(), 3));
		}
		estatisticas.put(level, registros);
	}
	
	// Rescreve o ficheiro ".txt", guardando as novas estatisticas no seu respectivo formato.
	public void salvarEstatisticasEmArquivo(String caminhoArquivo) {
		try {
			File file = new File(caminhoArquivo);

			if (file.exists()) {
				file.delete();
			}

			file.createNewFile();

			PrintWriter writer = new PrintWriter(file);

			for (Map.Entry<Integer, List<Registro>> entry : estatisticas.entrySet()) {
				int level = entry.getKey();
				List<Registro> registros = entry.getValue();

				writer.print(level + ":");

				for (Registro registro : registros) {
					writer.print(registro.getNomeJogador() + "," + registro.getPontuacao() + ";");
				}

				// Adiciona uma quebra de linha entre os níveis
				writer.println();
			}

			writer.close();

		} catch (IOException e) {
			System.err.println("Erro ao salvar estatisticas");
		}
	}

	@Override
	public String toString() {

		StringBuilder sb = new StringBuilder("Estatisticas [\n");

		for (Map.Entry<Integer, List<Registro>> entry : estatisticas.entrySet()) {
			int nivel = entry.getKey();
			List<Registro> pontuacoesNivel = entry.getValue();

			sb.append("  Nível ").append(nivel).append(":\n");

			for (Registro registro : pontuacoesNivel) {
				sb.append("    ").append(registro.getNomeJogador()).append(": ").append(registro.getPontuacao())
						.append("\n");
			}

			// Adiciona uma linha em branco entre os níveis
			sb.append("\n");
		}

		sb.append("]");
		return sb.toString();
	}

}
