package estatisticas;

public class Registro {

	private String nomeJogador;
	private int pontuacao;

	public Registro(String nomeJogador, int pontuacao) {
		this.nomeJogador = nomeJogador;
		this.pontuacao = pontuacao;
	}

	public String getNomeJogador() {
		return nomeJogador;
	}

	public int getPontuacao() {
		return pontuacao;
	}

}